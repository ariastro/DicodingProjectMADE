package com.otto.paulus.footballmatchschedule.model

data class TeamResponse (
        val teams: List<Team>
)