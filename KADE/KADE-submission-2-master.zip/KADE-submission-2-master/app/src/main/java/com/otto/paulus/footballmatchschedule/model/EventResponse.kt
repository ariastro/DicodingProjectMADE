package com.otto.paulus.footballmatchschedule.model

data class EventResponse (
        val events: List<Event>
)